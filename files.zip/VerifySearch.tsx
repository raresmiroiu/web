"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function VerifySearch({ defaultValue = "" }: { defaultValue?: string }) {
    const router = useRouter();
    const [code, setCode] = useState(defaultValue);

    const handleSubmit = () => {
        const trimmed = code.trim().toUpperCase();
        if (!trimmed) return;
        router.push(`/verify/${trimmed}`);
    };

    return (
        <div style={{ display: "flex", gap: 10, width: "100%", maxWidth: 480 }}>
            <input
                value={code}
                onChange={e => setCode(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") handleSubmit(); }}
                placeholder="SIG-XXXXXXXX"
                style={{
                    flex: 1, padding: "11px 16px",
                    background: "#131614", border: "1px solid #2e332e",
                    borderRadius: 4, color: "#e8e4db", fontSize: 14,
                    outline: "none", fontFamily: "monospace", letterSpacing: "0.05em",
                }}
                onFocus={e => e.target.style.borderColor = "#c9a84c"}
                onBlur={e => e.target.style.borderColor = "#2e332e"}
            />
            <button
                onClick={handleSubmit}
                style={{
                    padding: "11px 22px",
                    background: "#c9a84c", color: "#0d0f0e",
                    border: "none", borderRadius: 4,
                    fontSize: 13, fontWeight: 500, cursor: "pointer",
                    whiteSpace: "nowrap",
                }}
            >
                Verifică
            </button>
        </div>
    );
}
